<template>
  <div class="event">
    <h1>Event page</h1>
  </div>
</template>
