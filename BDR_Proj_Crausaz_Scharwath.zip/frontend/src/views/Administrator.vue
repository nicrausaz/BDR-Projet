<template>
  <div class="administrator">
    <h1>Admin page</h1>
  </div>
</template>
