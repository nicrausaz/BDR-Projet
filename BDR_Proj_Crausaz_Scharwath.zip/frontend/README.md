# Projet BDR [Frontend]
> Nicolas Crausaz et Maxime Scharwath

Le frontend est une application Vue.js

## Installation [Frontend]

```batch
$ cd ./frontend

$ npm install

$ npm run serve
```

Le frontend est maintenant démarré sur http://localhost:8080

---
<div style="text-align: right"> Nicolas Crausaz et Maxime Scharwath - 20.01.2020</div>